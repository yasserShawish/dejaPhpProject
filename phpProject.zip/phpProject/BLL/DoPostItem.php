<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DoPostItem
 *
 * @author yasser
 */
include_once '../../DAL/AccessDatabase.php';

class DoPostItem {

    private $itemInfo;

    function __construct($itemInfo) {
        $this->itemInfo = $itemInfo;
        $done = $this->AddItemToDB();
        
        if ($done) {            
            $_SESSION['AddedItemSucess'] = "<div class='here-pop-sucess'></div>";             
            RedirectTo::page("AdminWidgetController.php");           
        } else {
            $_SESSION['AddedItemFailed'] = "<div class='here-pop-error'></div>"; 
            RedirectTo::page("AdminWidgetController.php");   
        }
    }

    function AddItemToDB() {
        $filename = "../../DAL/DBConstant.php";
        
        if($this->itemInfo->IsEmtpy()){            
            return false;        
        }
        try {
            (new AccessDatabase($filename))->executeInsertQuery("INSERT INTO items(Description,Title,admin_id, imgPath,price) VALUES ('" . $this->itemInfo->getDescription() . "','" . $this->itemInfo->getTitle() . "'," . $this->itemInfo->getUser()->getId() . ",'" . $this->itemInfo->getImgPath() . "','".$this->itemInfo->getPrice() ."');");
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return false;
        }
        return true;
    }

}
