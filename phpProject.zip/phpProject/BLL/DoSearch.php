<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include '../../DAL/AccessDatabase.php';
include '../../Portal/Model/ItemsListModel.php';

class DoSearch {
    var $searchKey;
    
    
    function __construct($searchKey) {
        $this->searchKey = trim($searchKey);         
        $arrayOfKeyWords = explode(" " ,$searchKey);
        
        $listResult = array();
        foreach ($arrayOfKeyWords as $value) {
            echo $value;
            $tempArray = $this->getAllItemsBasedOnKeyWord($value);
            foreach ($tempArray as $value2) {
                echo $value2->getTitle();
                if(!in_array($value2->getTitle(), $listResult, true)){
                    array_push($listResult, $value2);
                }
            }
        }
//        
//        $uniques = array();
//        foreach ($listResult as $obj) {
//            $uniques[$obj->getDescription()] = $obj;
//        }
//     
        session_start();
        $_SESSION['searchResult'] = $listResult ;
    }
    
    function getAllItemsBasedOnKeyWord($keyword){
        $filename = "../../DAL/DBConstant.php";
        try{
            $command = "select * from items where title like '%".$keyword."%'";
        $dbSetOfserch = (new AccessDatabase($filename))->executeQuery($command);
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return false;
        }
        $array = array();
        
        while ($row = $dbSetOfserch->fetch_assoc()) {
            $item = new ItemsListModel($row["id"], $row["admin_id"], $row["Title"], $row["imgPath"], $row["price"], $row["Description"], $row["Publish_Date"]);            
            array_push($array, $item);
        }       
       
       return $array;
    }
}
