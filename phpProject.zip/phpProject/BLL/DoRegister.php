<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DoRegister
 *
 * @author yasser
 */
include '../../DAL/AccessDatabase.php';

class DoRegister {

    function __construct($userRegister) {


        $success = $this->addRegisterInfo($userRegister);

        if ($success) {
            session_start();
            $_SESSION['username'] = $userRegister->getFirstName();
            $regId = $this->getUserId($userRegister->getEmailAddress());
            $logedInUser = new LogedInUserModel($userRegister->getEmailAddress(), $userRegister->getFirstName(), $regId);
            $_SESSION['LogedInUserInfo'] = $logedInUser;
            RedirectTo::page("HomeController.php");
        } else
            echo "fuck you :)";
    }

    function addRegisterInfo($userRegister) {

        $filename = "../../DAL/DBConstant.php";

        try {
            (new AccessDatabase($filename))->executeInsertQuery("INSERT INTO user_info(first_name,last_name, password, email ,date_created) VALUES ('" . $userRegister->getFirstName() . "','" . $userRegister->getLastName() . "','" . $userRegister->getPassword() . "','" . $userRegister->getEmailAddress() . "',CURDATE());");
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return false;
        }
        return true;
    }

    function getUserId($email) {

        $filename = "../../DAL/DBConstant.php";
        $RegId = null;
        try {
            $db_result = (new AccessDatabase($filename))->executeQuery("select  id from user_info where email = '" . $email . "';");

            while ($row = mysqli_fetch_row($db_result)) {
                $RegId = $row[0];
            }

            if (mysqli_num_rows($db_result) == 0) {
                return $RegId;
            }
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return $RegId;
        }

        return $RegId;
    }

}
