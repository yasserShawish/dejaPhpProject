<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AddToCart
 *
 * @author yasser
 */
include_once '../../DAL/AccessDatabase.php';

class AddToCart {

    function __construct($itemId) {
        $itemsAddedToCart = array();
        $itemInfo = $this->getItemInfo($itemId);

        if ($itemInfo != null) {
            if (isset($_SESSION["ItemsOnCart"])) {
                $itemsAddedToCart = $_SESSION["ItemsOnCart"];
                array_push($itemsAddedToCart, $itemInfo);
                $_SESSION["ItemsOnCart"] = $itemsAddedToCart;
            } else {
                array_push($itemsAddedToCart, $itemInfo);
                $_SESSION["ItemsOnCart"] = $itemsAddedToCart;
            }
        }
    }

    function getItemInfo($itemId) {

        $filename = "../../DAL/DBConstant.php";
        $itemInfo = null;
        try {
            $db_result = (new AccessDatabase($filename))->executeQuery("select  * from items where id = " . $itemId . ";");

            while ($row = mysqli_fetch_row($db_result)) {
                $itemInfo = new ItemsListModel($row[0], $row[4], $row[2], $row[5], $row[6], $row[1], $row[3]);
            }

            if (mysqli_num_rows($db_result) == 0) {
                return Null;
            }
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return NULL;
        }
        return $itemInfo;
    }

}
