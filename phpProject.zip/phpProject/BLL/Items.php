<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Items
 *
 * @author yasser
 */
include_once '../../../DAL/AccessDatabase.php';
include_once '../../../Portal/Model/ItemsListModel.php';

class Items {

    public static function getAllItems() {

        $filename = "../../../DAL/DBConstant.php";
        $itemsList = array();
        try {
            $db_result = (new AccessDatabase($filename))->executeQuery("select  * from items ;");


            if ($db_result->num_rows > 0) {
                // output data of each row
                while ($row = $db_result->fetch_assoc()) {
                    $item = new ItemsListModel($row["id"], $row["admin_id"], $row["Title"], $row["imgPath"], $row["price"], $row["Description"], $row["Publish_Date"]);
                    array_push($itemsList, $item);
                }
            } else {
                $itemsList = null;
            }
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return $itemsList;
        }
        return $itemsList;
    }

    public static function displayAllItems() {

        $filename = "../DAL/DBConstant.php";

        try {
            $db_result = (new AccessDatabase($filename))->executeQuery("select  * from items ;");


            if ($db_result->num_rows > 0) {
                echo "<html><head>";
                echo "<style>
                        thead {color:green;}
                        tbody {color:blue;}
                        tfoot {color:red;}

                        table, th, td {
                        border: 1px solid black;
                        }
                        </style>";
                echo "</head>";
                echo '<table style="width:100%;border:1px solid black;">';
                echo "<thead><tr><th>id</th><th>Title</th><th>admin id</th><th>description</th><th>imgPath</th><th>Price</th><th>publish date</th></tr></thead>";
                echo '<tbody>';
                // output data of each row
                while ($row = $db_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td><td>" . $row["Title"] . "</td><td>" . $row["admin_id"] . "</td><td>" . $row["Description"] . "</td><td>" . $row["imgPath"] . "</td><td>" . $row["price"] . "</td><td>" . $row["Publish_Date"] . "</td>";
                    echo "</tr>";
                }

                echo '</tbody></table>';
                echo "</html>";
            } else {
                echo "0 results";
            }
        } catch (Exception $exc) {
            echo $exc->getMessage();
            return false;
        }

        return "";
    }

}

#Items::displayAllItems();
