/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    var redirectUriVal = $('input[name=redirectUri]').val();

    $(".add-to-cart-button").click(function () {
        var itemIdVal = $(this).attr("data-item-id");

        $.post("../../Controller/TransactionController.php",
                {
                    itemId: itemIdVal
                },
        function (data, status) {

            if (data.length > 100) {
                $("#loginfrag").html(data);
                $.notify("Item added to cart Successfully", "success");
            }
            else
            {
                alert(data);
            }
            //$("#loginfrag").load("../../View/Account/loginFragment.php");
        });
    });

});

