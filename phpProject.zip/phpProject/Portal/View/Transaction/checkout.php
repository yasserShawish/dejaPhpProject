<?php
require("../../Model/ItemsListModel.php");
require("../../Model/LogedInUserModel.php");
session_start();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Deja Bootstarp Website Template | Checkout :: w3layouts</title>
        <link href="../../Content/css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="../../Content/js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <link href="../../Content/css/style.css" rel='stylesheet' type='text/css' />
        <link href="../../Content/css/component.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--webfont-->
        <link href='http://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
        <script src="../../Content/js/jquery.easydropdown.js"></script>
        <!-- Add fancyBox main JS and CSS files -->
        <script src="../../Content/js/jquery.magnific-popup.js" type="text/javascript"></script>
        <link href="../../Content/css/magnific-popup.css" rel="stylesheet" type="text/css">
        <style>
            body {
                margin: 0;
                min-width: 250px;
            }

            /* Include the padding and border in an element's total width and height */
            .TEST * {
                box-sizing: border-box;
            }

            /* Remove margins and padding from the list */
            .TEST ul {
                margin: 0;
                padding: 0;
            }

            /* Style the list items */
            .TEST ul li {
                cursor: pointer;
                position: relative;
                padding: 12px 8px 12px 40px;
                background: #eee;
                font-size: 18px;
                transition: 0.2s;

                /* make the list items unselectable */
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            /* Set all odd list items to a different color (zebra-stripes) */
            .TEST ul li:nth-child(odd) {
                background: #f9f9f9;
            }

            /* Darker background-color on hover */
            .TEST ul li:hover {
                background: #ddd;
            }

            /* When clicked on, add a background color and strike out text */
            .TEST ul li.checked {
                background: #888;
                color: #fff;
                text-decoration: line-through;
            }

            /* Add a "checked" mark when clicked on */
            .TEST ul li.checked::before {
                content: '';
                position: absolute;
                border-color: #fff;
                border-style: solid;
                border-width: 0 2px 2px 0;
                top: 10px;
                left: 16px;
                transform: rotate(45deg);
                height: 15px;
                width: 7px;
            }

            /* Style the close button */
            .TEST .close {
                position: absolute;
                right: 0;
                top: 0;
                padding: 12px 16px 12px 16px
            }

            .TEST .close:hover {
                background-color: #f44336;
                color: white;
            }

            /* Style the header */
            .TEST .header {
                background-color: #f44336;
                padding: 30px 40px;
                color: white;
                text-align: center;
            }

            /* Clear floats after the header */
            .TEST .header:after {
                content: "";
                display: table;
                clear: both;
            }

            /* Style the input */
            .TEST input {
                border: none;
                width: 75%;
                padding: 10px;
                float: left;
                font-size: 16px;
            }

            /* Style the "Add" button */
            .TEST .addBtn {
                padding: 10px;
                width: 25%;
                background: #d9d9d9;
                color: #555;
                float: left;
                text-align: center;
                font-size: 16px;
                cursor: pointer;
                transition: 0.3s;
            }

            .TEST .addBtn:hover {
                background-color: #bbb;
            }
            .main{
                padding: 40px 10px;
                margin: 20px 10px;
                border: 1px solid black;
                list-style-type:none;   
            }
            .main .TEST li{
                list-style-type:none; 
            }
        </style>

        <script>
            $(document).ready(function () {
                $('.popup-with-zoom-anim').magnificPopup({
                    type: 'inline',
                    fixedContentPos: false,
                    fixedBgPos: true,
                    overflowY: 'auto',
                    closeBtnInside: true,
                    preloader: false,
                    midClick: true,
                    removalDelay: 300,
                    mainClass: 'my-mfp-zoom-in'
                });
            });
        </script>
        <!----details-product-slider--->
    </head>
    <body>
        <div class="single">
            <div class="container">
                <div class="header-top">
                    <div class="logo" style="float:right">
                        <a href="../Home/index.php"><img src="../../Content/images/logo.png" alt=""/></a>
                    </div>
                    <div class="header_right">  
                        <ul class="social">
                            <li><a href=""> <i class="fb"> </i> </a></li>
                            <li><a href=""><i class="tw"> </i> </a></li>
                            <li><a href=""><i class="utube"> </i> </a></li>
                            <li><a href=""><i class="pin"> </i> </a></li>
                            <li><a href=""><i class="instagram"> </i> </a></li>
                        </ul>
                        <div class="lang_list">
                            <select tabindex="4" class="dropdown">
                                <option value="" class="label" value="">En</option>
                                <option value="1">English</option>
                                <option value="2">French</option>
                                <option value="3">German</option>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>  
                <div class="apparel_box" id="loginfrag">
                    <?php include '../Account/loginFragment.php'; ?> 
                </div>
            </div>
        </div>
        <div class="main">
            <h2>Item List :</h2>
            <div class="TEST">
                <ul >                            
                    <li> <div style="width: 650px;"><b>Title</b><span style="float:right"><b>Price</b></span></div></li>                            
                </ul>
            </div>
            <?php
            if (isset($_SESSION["ItemsOnCart"]) && !empty($_SESSION["ItemsOnCart"])) {
                $variableSearch = $_SESSION["ItemsOnCart"];
                foreach ($variableSearch as $key => $value) {
                    ?>
                    <div class="TEST">
                        <ul id="myUL">
                            <li data-item-id="<?php echo $value->getId(); ?>"> <div style="width: 650px;"><?php echo $value->getTitle(); ?><span style="float:right;color:green">$<?php echo $value->getPrice(); ?></span></div></li>                            
                        </ul>
                    </div>

                    <script>
                        // Create a "close" button and append it to each list item

                        $('#myUL li').each(function (i)
                        {
                            var span = document.createElement("SPAN");
                            var txt = document.createTextNode("\u00D7");
                            span.className = "close";
                            span.appendChild(txt);
                            $(this).append(span);

                        });

                        // Click on a close button to hide the current list item
                        var close = document.getElementsByClassName("close");
                        var i;
                        for (i = 0; i < close.length; i++) {
                            close[i].onclick = function () {
                                var div = this.parentElement;
                                div.style.display = "none";

                                var itemIdVal = $(this).parent().attr("data-item-id");

                                $.post("../../Controller/TransactionController.php",
                                        {
                                            itemId: itemIdVal,
                                            toDelete: "YES"
                                        },
                                function (data, status) {
                                    //alert("Data: " + data + "\nStatus: " + status);

                                    $("#loginfrag").html(data);
                                    var total = $("#lototal").html();
                                    $("#CKTOTAL").html(total);
                                    var checkIfZero = $('.yellow').html();
                                    if (checkIfZero.charAt(0) == '0') {

                                        $("#myUL").html('<div class="main"><div class="container"><div class="register"><h4 class="title">Shopping cart is empty</h4><p class="cart">You have no items in your shopping cart.<br>Click<a href="../Home/index.php"> here</a> to continue shopping</p></div></div></div>');
                                    }

                                    //$("#loginfrag").load("../../View/Account/loginFragment.php");
                                });
                            };
                        }


                        // Add a "checked" symbol when clicking on a list item
                        var list = document.querySelector('ul');
                        list.addEventListener('click', function (ev) {
                            if (ev.target.tagName === 'LI') {
                                ev.target.classList.toggle('checked');
                            }
                        }, false);

                        // Create a new list item when clicking on the "Add" button
                        //                    function newElement() {
                        //                      var li = document.createElement("li");
                        //                      var inputValue = document.getElementById("myInput").value;
                        //                      var t = document.createTextNode(inputValue);
                        //                      li.appendCh ild(t);
                        //                      if (inputValue === '') {
                        //                        alert("You must write something!");
                        //                      } else {
                        //                        document.getElementById("myUL").appendChild(li);
                        //                      }
                        //                      document.getElementById("myInput").value = "";
                        //                    
                        //                      var span = document.createElement("SPAN");
                        //                      var txt = document.createTextNode("\u00D7");
                        //                      span.className = "close";
                        //                      span.appendChild(txt);
                        //                      li.appendChild(span);
                        //                    
                        //                      for (i = 0; i < close.length; i++) {
                        //                        close[i].onclick = function() {
                        //                          var div = this.parentElement;
                        //                          div.style.display = "none";
                        //                        }
                        //                      }
                        //                    }
                    </script>

                    <?php
                }

                echo "<h2 style='color:red;float:right;'>Total : " . '$<span id="CKTOTAL">' . $total . "</span></h2>";
            } else {
                ?>

                <div class="container">
                    <div class="register">
                        <h4 class="title">Shopping cart is empty</h4>
                        <p class="cart">You have no items in your shopping cart.<br>Click<a href="../Home/index.php"> here</a> to continue shopping</p>
                    </div>
                </div>
            <?php } ?>

        </div>

        <div class="container">
            <div class="row" >
                <div class="col-xs-4 col-xs-offset-8">
                    <form method="post" action="payment.php">
                        <button type="submit" class="btn btn-info" style="margin-bottom: 20px;">Proceed To Check Out</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="brands">
                <ul class="brand_icons">
                    <li><img src='../../Content/images/icon1.jpg' class="img-responsive" alt=""/></li>
                    <li><img src='../../Content/images/icon2.jpg' class="img-responsive" alt=""/></li>
                    <li><img src='../../Content/images/icon3.jpg' class="img-responsive" alt=""/></li>
                    <li><img src='../../Content/images/icon4.jpg' class="img-responsive" alt=""/></li>
                    <li><img src='../../Content/images/icon5.jpg' class="img-responsive" alt=""/></li>
                    <li><img src='../../Content/images/icon6.jpg' class="img-responsive" alt=""/></li>
                    <li class="last"><img src='../../Content/images/icon7.jpg' class="img-responsive" alt=""/></li>
                </ul>
            </div>
        </div>
        <div class="footer">
            <div class="container">
                <div class="footer-grid">
                    <h3>Category</h3>
                    <ul class="list1">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Eshop</a></li>
                        <li><a href="#">Features</a></li>
                        <li><a href="#">New Collections</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Our Account</h3>
                    <ul class="list1">
                        <li><a href="#">Your Account</a></li>
                        <li><a href="#">Personal information</a></li>
                        <li><a href="#">Addresses</a></li>
                        <li><a href="#">Discount</a></li>
                        <li><a href="#">Orders history</a></li>
                        <li><a href="#">Addresses</a></li>
                        <li><a href="#">Search Terms</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Our Support</h3>
                    <ul class="list1">
                        <li><a href="#">Site Map</a></li>
                        <li><a href="#">Search Terms</a></li>
                        <li><a href="#">Advanced Search</a></li>
                        <li><a href="#">Mobile</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Mobile</a></li>
                        <li><a href="#">Addresses</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Newsletter</h3>
                    <p class="footer_desc">Nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
                    <div class="search_footer">
                        <input type="text" class="text" value="Insert Email" onfocus="this.value = '';" onblur="if (this.value == '') {
                                    this.value = 'Insert Email';
                                }">
                        <input type="submit" value="Submit">
                    </div>
                    <img src="../../Content/images/payment.png" class="img-responsive" alt=""/>
                </div>
                <div class="footer-grid footer-grid_last">
                    <h3>About Us</h3>
                    <p class="footer_desc">Diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,.</p>
                    <p class="f_text">Phone:  &nbsp;&nbsp;&nbsp;00-250-2131</p>
                    <p class="email">Email: &nbsp;&nbsp;&nbsp;<span>info(at)Deja.com</span></p>	
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="footer_bottom">
            <div class="container">
                <div class="copy">
                    <p>&copy; 2014 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
                </div>
            </div>
        </div>
    </body>
</html>		