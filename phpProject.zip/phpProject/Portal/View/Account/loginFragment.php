
<div id = "loginFragment">

    <ul class = "login">
        <?php
        if (isset($_SESSION['LogedInUserInfo'])) {

            $loginUserName = $_SESSION['LogedInUserInfo'];
            ?>
            <li class = "login_text"><a href = "../Account/myInfo.php"><?php
                    echo 'welcome ' . $loginUserName->getName();
                    ?></a></li>

            <li class = "wish"><a href = "../../Controller/LogoutController.php">Logout</a></li>
            <div class = 'clearfix'></div>
        </ul>

        <div class = "cart_bg">
            <ul class = "cart">
                <i class = "cart_icon"></i><p class = "cart_desc">

                    <?php
                    $total = 0;

                    if (isset($_SESSION["ItemsOnCart"])) {
                        foreach ($_SESSION["ItemsOnCart"] as $key => $value) {
                            $total += $value->getPrice();
                        }
                    }
                    echo '$<span id="lototal" >' . $total.'</span>';
                    ?>
                    <br>
                    <span class = "yellow"><?php echo isset($_SESSION["ItemsOnCart"]) ? count($_SESSION["ItemsOnCart"]) : 0; ?> Item's</span></p>
                <div class = 'clearfix'></div>
            </ul>
            <ul class = "product_control_buttons">
                <li><a href = "#"><img src = "../../Content/images/close.png" alt = ""/></a></li>
                <li><a href = "#">Edit</a></li>
            </ul>
            <div class = 'clearfix'></div>
        </div>
        <ul class = "quick_access">
            <li class = "view_cart"><a href = "../Transaction/checkout.php">View Cart</a></li>
            <li class = "check"><a href = "../Transaction/checkout.php">Checkout</a></li>
            <div class = 'clearfix'></div>
        </ul>

        <?php
    } else {
        ?>


        <li class = "login_text"><a href = "../Account/login.php">Login</a></li>

        <li class = "wish"><a href = "../Account/register.php">Register</a></li>
        <div class = 'clearfix'></div>
    </ul>       

    <?php
}
?>
</div>
