<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>








        <?php
        /*
         * 
         * OOP ->  
         * 
         * 
         * 
         *          */

        class Car {

            var $color;
            var $name;
            var $date;
            var $speed;
            var $id;

            function __construct($myColor) {
                $this->color = $myColor;
            }
                    
            function MoveToRight() {
                echo 'move to right';
            }


            function MoveTOLeft() {
                
            }

            function MoveToFront() {
                
            }

        }

        $BMW = new Car("RED");
        

        echo $BMW->color;
        ?>























        <!--
        
            CREATE TABLE `user_info` (
            `first_name` varchar(30) NOT NULL,
            `last_name` varchar(40) NOT NULL,
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `password` varchar(30) NOT NULL,
            `email` varchar(40) NOT NULL,
            PRIMARY KEY (`id`)
           )
------------------------------
        CREATE TABLE `items` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `Description` text NOT NULL,
        `Title` text NOT NULL,
        `Publish_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
       )
        ------------------------------------------------
        CREATE TABLE `admin` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `name` text NOT NULL,
 `password` text NOT NULL,
 `email` int(11) NOT NULL,
 `date_created` date NOT NULL,
 PRIMARY KEY (`id`)
)
        -->


    </body>
</html>
