<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class PostModel{
    
    var $discripstion;
    var $user;
    var $date;
    var $title;
    var $price;
    var $imgPath;
    
    
    function __construct($discription , $user , $date , $title , $price ,$path ){
        $this->discripstion = $discription;
        $this->user = $user;
        $this->date = $date;
        $this->title = $title;
        $this->price = $price;
        $this->imgPath = $path;
    }
    
    public function getPrice(){
        return $this->price;
    }
    
    public function getImgPath(){
        return $this->imgPath;
    }
    
    public function setImgPath($path){
         $this->imgPath = $path;
    }
    
    public function getDescription(){
        return $this->discripstion;
    }
    
    public function getUser(){
        return $this->user;
    }
    
     public function getDate(){
        return $this->date;
    }
    
     public function getTitle(){
        return $this->title;
    }
    
    
    public function __toString() {
        return trim($this->discripstion);
    }
    
    public function IsEmtpy() {        
        $title = trim($this->title);
        $price = trim($this->price);
        
        if(empty($title) || empty($price) || empty($this->user))
            return true;
        return false;
    }
    
}