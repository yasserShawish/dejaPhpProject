<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ItemsListModel
 *
 * @author yasser
 */
class ItemsListModel {

    //put your code here
    private $title;
    private $id;
    private $adminId;
    private $imgPath;
    private $price;
    private $description;
    private $publishDate;

    function __construct($id, $adminId, $title, $imgPath, $price, $description, $publishDate) {
        $this->setId($id);
        $this->setAdminId($adminId);
        $this->setImgPath($imgPath);
        $this->setPrice($price);
        $this->setPublishDate($publishDate);
        $this->setTitle($title);
        $this->setDescription($description);
    }

    public function getTitle() {
        return $this->title;
    }

    public function setTitle($title) {
        $this->title = $title;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getAdminId() {
        return $this->adminId;
    }

    public function setAdminId($adminId) {
        $this->adminId = $adminId;
    }

    public function getImgPath() {
        return $this->imgPath;
    }

    public function setImgPath($imgPath) {
        $this->imgPath = $imgPath;
    }

    public function getPrice() {
        return $this->price;
    }

    public function setPrice($price) {
        $this->price = $price;
    }

    public function getPublishDate() {
        return $this->publishDate;
    }

    public function setPublishDate($publishDate) {
        $this->publishDate = $publishDate;
    }

    public function getDescription() {
        return $this->description;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function buildGetUrl() {
        return "title=" . $this->getTitle() . "&" . "price=" . $this->getPrice() . "&" . "desc=" . $this->getDescription() . "&" . "adminid=" . $this->getAdminId() . "&" . "id=" . $this->getId() . "&" . "publishDate=" . $this->getPublishDate() . "&" . "imgPath=" . $this->getImgPath() . "";
    }

}
