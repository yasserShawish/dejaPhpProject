<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include '../../BLL/RedirectTo.php';

session_start();
if (isset($_SESSION['LogedInUserInfo'])) {
    RedirectTo::page("../View/AdminWidgets/addItems.php");
} else {
    RedirectTo::page("../View/Home/index.php");
}