<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once '../../BLL/RedirectTo.php';
require("../Model/LogedInUserModel.php");
require("../Model/ItemsListModel.php");
require("../../BLL/AddToCart.php");

session_start();

if ($_POST) {

    if (isset($_POST["itemId"]) && isset($_SESSION['LogedInUserInfo'])) {
        $itemId = $_POST["itemId"];

        if (isset($_POST["toDelete"])) {
            if ($_POST["toDelete"] == "YES") {
                if (isset($_SESSION["ItemsOnCart"])) {
                    $itemsAddedToCart = $_SESSION["ItemsOnCart"];

                    foreach ($itemsAddedToCart as $key => $value) {
                        if ($value->getId() == $itemId) {
                            unset($itemsAddedToCart[$key]);
                            break;   
                        }
                    }
                    $_SESSION["ItemsOnCart"] = $itemsAddedToCart;
                }
            }
        } else {
            new AddToCart($itemId);
        }

        include_once '../View/Account/loginFragment.php';
    } else {
        echo 'YOU SHOULD LOGGED IN TO ADD TO CART';
//        $redirectUri = $_POST['redirectUri'];
//        RedirectTo::page($redirectUri);        
    }
}
