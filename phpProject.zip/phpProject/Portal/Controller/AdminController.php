<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require('../Model/LogedInUserModel.php');
include_once '../Model/PostModel.php';
include_once '../../BLL/DoPostItem.php';
include_once '../../BLL/RedirectTo.php';

if ($_POST) {

    if (isset($_POST['submit']) AND $_POST['submit'] == "addItem") {

        session_start();

        $desc = $_POST['desc'];
        $price = $_POST['price'];
        $title = $_POST['title'];
        $imgPath = '';
    
        $filename = "../Model/upload.php";
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if (is_file($filename) && $check !== false) {            
            include $filename;
    
            $imgPathNew = str_replace("../", "", $target_file);
            $imgPath = $_SERVER['SERVER_NAME'] . "/phpProject/Portal/" . $imgPathNew;
        }

        $logedUserinfo = $_SESSION['LogedInUserInfo'];
        $postInfo = new PostModel($desc, $logedUserinfo, date("Y-m-d"), $title, $price, $imgPath);

        new DoPostItem($postInfo);
    }
}



